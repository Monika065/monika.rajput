import React, { useState } from "react"
import Head from "./Head"
import "./header.css"
import SearchIcon from '@material-ui/icons/Search';
//import DehazeIcon from '@material-ui/icons/Dehaze';
import { NavLink,Link } from "react-router-dom"

//import { useNavigate } from 'react-router-dom'
//import { NavLink } from 'react-router-dom'

//import{ Button } from '@mui/material'

const Header = (props) => {
  const [navbar, setNavbar] = useState(false)
  //const navigate=useNavigate();

  return (
    <>
      <Head />
      <header>
       
        <div className='container paddingSmall'>
          <div>
            <ul className={navbar ? "navbar" : "flex"} onClick={() => setNavbar(false)}>
              <li>
              
                <Link to='/'>Home</Link>
              </li>
              <li>
                <NavLink to='/culture'>Culture</NavLink>
              </li>
              <li>
                <Link to='/politics'>Politics</Link>
              </li>
              <li>
                <Link to='/memes'>Memes</Link>
              </li>
              <li>
                <Link to='/sports'>Sports</Link>
              </li>
              <li>
                <Link to='/entertainment'>Entertainment</Link>
              </li>
              <li>
                <Link to='/cricket'>Cricket</Link>
              </li>
              <li>
                <Link to='/web series'>Web Series</Link>
              </li>
              <li>
                <Link to='/blogs'>Blogs</Link>
              </li>
                    <li> 
                    <div className="header__right">
                        <SearchIcon className="header__icon" />
                       
                        </div>
                  
                    </li>
                    <li>
                      <Link to='/logout'> Logout</Link>
                    </li>
                    
                    </ul>
                   
                   
       
        
     
                    
            <button className='barIcon' onClick={() => setNavbar(!navbar)}>
              {navbar ? <i className='fa fa-times'></i> : <i className='fa fa-bars'></i>}
         </button>
         </div>
         </div>
         
        
         
        
         </header>
       
         </>
    
    
  
  )
}

export default Header


/*import Login from "./comonents/Login";
import "./header_style.scss";
import { setClicked } from "../../redux/features/authenticationSlice";
import { useDispatch, useSelector } from "react-redux";
const Header_sec = () => {
  const { user } = useSelector((state) => state.authentication);
  const dispatch = useDispatch();
  return (
    <div className="headerSec w-full h-[70px] flex py-4 px-8 justify-between items-center">
      <h1 className="center_LOGO grow sm:text-center sm:translate-x-12 text-left ">WebNews</h1>

      <div className="sideOptions">
        <button
          className="login_btn btn"
          onClick={() => {
            console.log("clicked");
            dispatch(setClicked());
          }}
        >
          {user ? user.charAt(0).toUpperCase() : "Log In"}
        </button>
        <Login />
      </div>
    </div>
  );
};

export default Header_sec;
*/

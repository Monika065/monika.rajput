import React from "react"
//import HeaderTop from "./components/common/header/HeaderTop "

import "./header.css"

const Head = () => {
  return (
    
   
    
     < div className="Head" >
        THE TIMES OF INDIA 
      </div>
           
             
         
      
  )
}

export default Head


import React from "react"

const Main = () => {
  return (
    <>
      <h1>Main content</h1>
    </>
  )
}

export default Main

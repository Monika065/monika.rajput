/*import "./App.css"
import Header from "./components/common/header/Header"

import {BrowserRouter as  Switch,Router,Route} from "react-router-dom"
import Footer from "./components/common/footer/Footer"
import Homepages from "./components/home/Homepages"
import Culture from "./components/culture/Culture"
//import SinglePage from "./components/singlePage/SinglePage"
import HeaderTop from "./components/common/header/HeaderTop"
//import Login from "./components/Login"
function App(){
  return(
  <>
   
<Router>
<HeaderTop/>
   <Header/>

 <Switch>
   
    <Route exact path='/' component={Homepages} />
    <Route exact path='/culture' component={Culture} />
   
    </Switch>

</Router>

<Footer/>
</>
  )
  }
export default App
*/
import React from "react"
import Header from "./components/common/header/Header"
import "./App.css"
import Homepages from "./components/home/Homepages"
import Footer from "./components/common/footer/Footer"
import { BrowserRouter as Router,Routes, Route } from "react-router-dom"
import SinglePage from "./components/singlePage/SinglePage"
//import Culture from "./components/culture/Culture"
//import HeaderTop from "./components/common/header/HeaderTop"
import Login from "./components/Login"
import  { useState } from 'react'
import News from "./components/news/News"

const App = () => {
  
    
     const [isLoggedIn, setIsLoggedIn] = useState(false);

const loginHandler = (email, password)=>{
   setIsLoggedIn(true)
}

const logoutHandler= ()=> {
    setIsLoggedIn(false)
}

  

   
    return(
  <>
   {!isLoggedIn && <Login onLogin={loginHandler} />}
    {isLoggedIn && <Header  onLogout = {logoutHandler}/>}
   
        <Header />
      
        <Routes>

          

          <Route exact path='/' element={<Homepages />}></Route>
          <Route path='/singlepage/:id' exact element={<SinglePage/>}></Route>
          
         
          </Routes>
         
       <News/>
        <Footer />
      
    </>
  )
}

export default App




/*import Header from '.components/common/header/Header'
import {  useState } from 'react';
import HeaderTop from "./components/common/header/HeaderTop"

const App = () => {
  const [stickMenu] = useState(false)

  const transitionNavBar = () => {
      if (window.scrollY > 100) {
          setStickMenu(true)
      }
      else {
          setStickMenu(false)
      }
  }
  
  return (
    <div>
        <HeaderTop />
        <Header stickMenu={stickMenu} />
</div>
    )
  }
  
  export default App
  */